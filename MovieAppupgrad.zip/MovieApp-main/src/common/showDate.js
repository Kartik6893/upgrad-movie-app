let showDate = [
  {
    id: 1,
    showDate: '1/1/2019',
  },
  {
    id: 2,
    showDate: '10/10/2018',
  },
  {
    id: 3,
    showDate: '12/12/2018',
  },
  {
    id: 4,
    showDate: '6/8/2018',
  },
  {
    id: 5,
    showDate: '8/8/2018',
  },
];

export default showDate;
